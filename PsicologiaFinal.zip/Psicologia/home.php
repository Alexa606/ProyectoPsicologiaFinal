<?php
    session_start();

    if (!isset($_SESSION['usuario'])) {
        // Redirigir a la página de inicio de sesión
        header("Location: index.php");
        exit();
    }

    $nombre=$_SESSION['nombre'];
    $apellido=$_SESSION['a_paterno'];
    $nombre=strtoupper($nombre);
    $apellido=strtoupper($apellido);

?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Departamento Psicología</title>
    <link rel="stylesheet" href="MenuNew.css">
</head>
<body>
    <header class="header">
        <div class="logo">DEPARTAMENTO DE PSICOLOGÍA</div>
        <input type="checkbox" id = "toggle">
        <label for="toggle"> <img class="menu" src="images/menu.svg" alt="menu"></label>
        <nav class="navegation">

            <ul>
                <li><a href="#">FORMULARIOS</a>
                    <ul>
                         <li><a href="http://localhost/Psicologia/Alumno-DireccionP.php">ALUMNOS</a></li>
                         <li><a href="http://localhost/Psicologia/Carrera.php">CARRERA</a></li>
                         <li><a href="http://localhost/Psicologia/Cita.php">CITA</a></li>
                         <li><a href="http://localhost/Psicologia/Consulta.php">CONSULTA</a></li>
                         <li><a href="http://localhost/Psicologia/Estado.php">ESTADO</a></li>
                         <li><a href="http://localhost/Psicologia/Jefe%20de%20divicion.php">JEFE DE DIVISIÓN</a></li>
                    </ul>
                </li>
                <li><a href="#">CONSULTA</a>
                    <ul>
                        <li><a href="ConexionPConsulta.php">ALUMNOS CON SUS CARRERAS</a></li>
                        <li><a href="ConexionSConsulta.php">ALUMNOS CON SUS TUTORES</a></li>
                        <li><a href="ConexionTConsulta.php">ALUMNOS CON SUS DIRECCIONES</a></li>
                        <li><a href="ConexionCConsulta.php">CITAS PROGRAMADAS</a></li>
                        <li><a href="ConexionQConsulta.php">ALUMNOS CON ANSIEDADES</a></li>
                    </ul>
                </li>
                <li><a href="#">USUARIOS</a>
                    <ul>
                        <li><a href="http://localhost/Psicologia/SuperUsuario.php">ADMINISTRADOR</a></li>
                        <li><a href="http://localhost/Psicologia/Tutor.php">TUTOR</a></li>
                    </ul>
                </li>
                <li><a href="#">PSICOLOGO <?php echo $nombre." ".$apellido; ?></a>
                    <ul>
                        <li><a href="logout.php">CERRAR SESIÓN</a></li>                       
                    </ul>
                </li>
            </ul>
        </nav>
    </header>
    <div class="hero"></div>
</body>
</html>