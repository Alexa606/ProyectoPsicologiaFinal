<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content = "IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CITA</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="estilo.css">


</head>
<body>
<form method="POST" action="conexionCita.php"  >
    <a href="home.php" class="menu-link">MENU</a>
                <h4>FORMULARIO CITA</h4>
                
    <div class = "input-group">

    <div class = "input-container">
        <input type="text" name="CLAVE_CITA" placeholder = "Clave de la cita">
        <i class = "fa-solid fa-id-card-clip" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="FECHA_HORA" placeholder = "Fecha y hora de la cita">
        <i class = "fa-solid fa-calendar" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="LUGAR" placeholder = "Lugar">
        <i class = "fa-solid fa-map-location-dot" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="CORREO_INSTITUCIONA" placeholder = "Correo institucional">
        <i class = "fa-solid fa-at" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="NO_CONTROL_ALUMNO" placeholder = "No. control del alumno">
        <i class = "fa-solid fa-id-card-clip" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="CLAVECONSULTA" placeholder = "Clave la consulta">
        <i class = "fa-solid fa-id-card-clip" ></i>
    </div>

    <input class="botons" type="submit" name = "RegistrarCITA" value="Registrar Cita">
    <br><br>
    <input class="botons" type="submit" name = "ActualizarCITA" value="Actualizar Cita">
    <br><br>
    <input class="botons" type="submit" name ="EliminarCITA" value="Eliminar Cita">
    
    </div>
    </form>

</body>
</html>