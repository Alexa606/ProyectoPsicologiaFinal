<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Resultados de la Consulta</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="ConsultaS.css">
    <link rel="stylesheet" type="text/css" href="estilo.css">
</head>
<body>
    <div class="input-container">
        <h2>CITAS PROGRAMADAS</h2>
        <table class="styled-table">
            <thead>
                <tr>
                    <th>Información de la Cita</th>
                </tr>
            </thead>
            <tbody>
            <?php
                // Conexión a la base de datos MySQL
                $servername = "127.0.0.1";
                $username = "root";
                $password = "";
                $database = "psicologa";

                $conn = mysqli_connect($servername, $username, $password, $database);

                if (!$conn) {
                    die("Error de conexión: " . mysqli_connect_error());
                } else {
                    // Ejecutar la consulta SQL
                    $sql = "SELECT CONCAT(A.NOMBRE, ' ', A.A_PATERNO, ' tiene una cita programada el día ', DATE_FORMAT(C.FECHA_HORA, '%d %M %Y %H:%i:%s')) AS INFO_CITA
                        FROM ALUMNO A
                        NATURAL JOIN CITA C
                        JOIN CONSULTA CT ON C.CLAVECONSULTA = CT.CLAVECONSULTA
                        WHERE A.NO_CONTROL = C.NO_CONTROL_ALUMNO AND C.CLAVECONSULTA = CT.CLAVECONSULTA
                        ORDER BY C.FECHA_HORA";

                    $result = mysqli_query($conn, $sql);

                    if (!$result) {
                        die("Error en la consulta: " . mysqli_error($conn));
                    }

                    // Continuar el código PHP después de la conexión
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo '<tr>';
                        echo '<td>' . $row['INFO_CITA'] . '</td>';
                        echo '</tr>';
                    }

                    mysqli_free_result($result);
                    mysqli_close($conn);
                }
            ?>

            </tbody>
        </table>
         <!-- Botones para imprimir -->
         <div class="btn-print">
            <button class="btn btn-success" onclick="window.print()">Imprimir Tabla</button>
        </div>
        <a href="home.php" class="menu-link">MENU</a>
    </div>
</body>
</html>
