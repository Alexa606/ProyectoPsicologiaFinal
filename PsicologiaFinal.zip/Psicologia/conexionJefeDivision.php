<?php
header('Content-Type: text/html; charset=UTF-8');
$CLAVEJD = $_POST['CLAVEJD'];
$NOMBRE = $_POST['NOMBRE'];
$A_PATERNO = $_POST['A_PATERNO'];
$A_MATERNO = $_POST['A_MATERNO'];
$GENERO = $_POST['GENERO'];
$EDAD = $_POST['EDAD'];
$TELEFONOC = $_POST['TELEFONOC'];
$CORREOE = $_POST['CORREOE'];

$conexion = new mysqli("127.0.0.1", "root", "", "psicologa");
$conexion->set_charset("utf8");

if ($conexion->connect_error) {
    die("Error de conexión a la base de datos: " . $conexion->connect_error);
}

if (isset($_POST['RegistrarJEFE'])) {
    $consulta = "INSERT INTO JEFE_DE_DIVISION (CLAVEJD, NOMBRE, A_PATERNO, A_MATERNO, GENERO, EDAD, TELEFONOC, CORREOE) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("issssiss", $CLAVEJD, $NOMBRE, $A_PATERNO, $A_MATERNO, $GENERO, $EDAD, $TELEFONOC, $CORREOE);

        if ($stmt->execute()) {
            echo "El Nuevo Jefe de División se registró con éxito.";
        } else {
            echo "Error al registrar: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}

if (isset($_POST['ActualizarJEFE'])) {
    $consulta = "UPDATE JEFE_DE_DIVISION 
        SET  NOMBRE = ?, A_PATERNO = ?, A_MATERNO = ?, GENERO = ?, EDAD = ?, TELEFONOC = ?, CORREOE = ?
        WHERE CLAVEJD = ?";

    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("sssssisi", $NOMBRE, $A_PATERNO, $A_MATERNO, $GENERO, $EDAD, $TELEFONOC, $CORREOE, $CLAVEJD);

        if ($stmt->execute()) {
            echo "La actualización fue exitosa.";
        } else {
            echo "Error al actualizar: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}

if (isset($_POST['EliminarJEFE'])) {
    $consulta = "DELETE FROM JEFE_DE_DIVISION WHERE CLAVEJD = ?";
    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("i", $CLAVEJD);

        if ($stmt->execute()) {
            echo "La eliminación fue exitosa.";
        } else {
            echo "Error durante la eliminación: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}

$conexion->close();
?>

