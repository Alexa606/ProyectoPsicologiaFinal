<?php
session_start();

$conexion = new mysqli("127.0.0.1", "root", "", "psicologa");
$conexion->set_charset("utf8");

$CLAVETUTOR=$_POST['CLAVE'];
$CONTRASEÑA=$_POST['CONTRASEÑA'];
$CLAVE_SU=$_POST['CLAVE'];
$CONTRASENA=$_POST['CONTRASEÑA'];
$TIPOUSUARIO=$_POST['TIPO_USUARIO'];

if($TIPOUSUARIO=="psicologo"){
    $CONSULTA="SELECT NOMBRE, A_PATERNO FROM super_usuario WHERE CLAVE_SU=? AND CONTRASENA=?";
    $stmt=$conexion->prepare($CONSULTA);

    if ($stmt) {
        $stmt->bind_param("ss", $CLAVE_SU, $CONTRASENA);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $filas = $resultado->num_rows;
    
        if ($filas) {
            $_SESSION['usuario']=$CLAVE_SU;
            header("location: http://localhost/Psicologia/home.php");
            $_SESSION['nombre']=$filas['NOMBRE'];
            $_SESSION['a_paterno']=$filas['A_PATERNO'];
        } else {
            include("index.php");
            echo "<h1>Usuario o contraseña incorrecta. Intenta de nuevo</h1>";
        }
    
        $stmt->close();

    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }

}else if($TIPOUSUARIO=="tutor"){
    $CONSULTA="SELECT NOMBRE, A_PATERNO FROM TUTOR WHERE CLAVETUTOR=? AND CONTRASEÑA=?";
    $stmt=$conexion->prepare($CONSULTA);
    if ($stmt) {
    $stmt->bind_param("ss", $CLAVETUTOR, $CONTRASEÑA);
    $stmt->execute();
    $resultado = $stmt->get_result();
    $filas = $resultado->num_rows;
    

    if ($filas) {
        $_SESSION['usuario']=$CLAVETUTOR;
        header("location: http://localhost/Psicologia/HomeTutor.php");
        $_SESSION['nombre']=$filas['NOMBRE'];
        $_SESSION['a_paterno']=$filas['A_PATERNO'];
    } else {
        include("index.php");
        echo "<h1>Usuario o contraseña incorrecta. Intenta de nuevo</h1>";
    }

    $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }

    $conexion->close();
}else{
    echo"<h1>Error de acceso verifique su usuario, contraseña y rol</h1>";
}

?>