
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content = "IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ALUMNO</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" 
    integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" 
    crossorigin="anonymous" referrerpolicy="no-referrer" />
    
    <link rel="stylesheet" type="text/css" href="estilo.css">
    
</head>
<body>
    <a href="HomeTutor.php" class="menu-link">MENU </a>
    <form method="POST" action="conexionDireccion.php"  >
                <h4>DIRECCIÓN</h4>
    <div class = "input-group">

    <div class = "input-container">
        <input type="text" name="CLAVE_DIRECCION" placeholder = "Clave de dirección">
        <i class = "fa-solid fa-id-card-clip" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="MUNICIPIO" placeholder = "Municipio">
        <i class = "fa-solid fa-location-dot" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="CP" placeholder = "Codigo Postal">
        <i class = "fa-solid fa-location-dot" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="CALLE" placeholder = "Calle">
        <i class = "fa-solid fa-location-dot" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="NUMERO" placeholder = "Número de calle">
        <i class = "fa-solid fa-location-dot" ></i>
    </div>
   
    <input class="botons" type="submit" name = "RegistrarDireccion" value="Registrar Dirección">
    <br><br>
    <input class="botons" type="submit" name = "ActualizarDireccion" value="Actualizar Dirección">
    <br><br>
    <input class="botons" type="submit" name ="EliminarDireccion" value="Eliminar Dirección">
    
    </div>
    </form>

    <form method="POST" action="conexionAlumno.php"  >

                <h4>DATOS DE ALUMNO</h4>
                
    <div class = "input-group">
    
    <div class = "input-container">
        <input type="text" name="NO_CONTROL" placeholder = "Numero de control">
        <i class = "fa-solid fa-id-card-clip" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="NOMBRE" placeholder = "Nombre">
        <i class = "fa-solid fa-user" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="A_PATERNO" placeholder = "Apellido paterno">
        <i class = "fa-solid fa-user" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="A_MATERNO" placeholder = "Apellido Materno">
        <i class = "fa-solid fa-user" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="F_NACIMIENTO" placeholder = "Fecha de nacimiento">
        <i class = "fa-solid fa-calendar" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="EDAD" placeholder = "Edad">
        <i class = "fa-solid fa-user" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="TELEFONO" placeholder = "Número de Telefono">
        <i class = "fa-solid fa-mobile" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="CORREO_INST" placeholder = "Correo Institucional">
        <i class = "fa-solid fa-at" ></i>
    </div>
    </div>
    </form>
    <form method="POST" action="conexionAlumno.php"  >
    <div class = "input-group">
    <div class = "input-container">
        <input type="text" name="GENERO" placeholder = "Genero">
        <i class = "fa-solid fa-venus-mars" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="GRUPO" placeholder = "Grupo">
        <i class = "fa-solid fa-graduation-cap" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="TURNO" placeholder = "Turno">
        <i class = "fa-solid fa-sun" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="SEMESTRE" placeholder = "Semestre">
        <i class = "fa-solid fa-graduation-cap" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="CLAVE_DIRECCION" placeholder = "Clave de dirección">
        <i class = "fa-solid fa-id-card-clip" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="CLAVECARRERA" placeholder = "Clave de carrera">
        <i class = "fa-solid fa-id-card-clip" ></i>
    </div>
    <input class="botons" type="submit" name = "RegistrarALUMNO" value="Registrar ALUMNO">
    <br><br>
    <input class="botons" type="submit" name = "ActualizarALUMNO" value="Actualizar ALUMNO">
    <br><br>
    <input class="botons" type="submit" name ="EliminarALUMNO" value="Eliminar ALUMNO">
    
    </div>
    </form>
</body>
</html>