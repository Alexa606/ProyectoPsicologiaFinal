<?php
header('Content-Type: text/html; charset=UTF-8');

$conexion = new mysqli("127.0.0.1", "root", "", "psicologa");
$conexion->set_charset("utf8");

if ($conexion->connect_error) {
    die("Error de conexión a la base de datos: " . $conexion->connect_error);
}

if (isset($_POST['RegistrarUSUARIO'])) {
    $CLAVE_SU = $_POST['CLAVE_SU'];
    $NOMBRE = $_POST['NOMBRE'];
    $A_PATERNO = $_POST['A_PATERNO'];
    $A_MATERNO = $_POST['A_MATERNO'];
    $CORREOE = $_POST['CORREOE'];
    $CONTRASENA = $_POST['CONTRASENA'];

    $consulta = "INSERT INTO Super_usuario (CLAVE_SU, NOMBRE, A_PATERNO, A_MATERNO, CORREOE, CONTRASENA) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("isssss", $CLAVE_SU, $NOMBRE, $A_PATERNO, $A_MATERNO, $CORREOE, $CONTRASENA);

        if ($stmt->execute()) {
            echo "El usuario se registró con éxito.";
        } else {
            echo "Error al registrar: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}

if (isset($_POST['ActualizarUSUARIO'])) {
    $CLAVE_SU = $_POST['CLAVE_SU'];
    $NOMBRE = $_POST['NOMBRE'];
    $A_PATERNO = $_POST['A_PATERNO'];
    $A_MATERNO = $_POST['A_MATERNO'];
    $CORREOE = $_POST['CORREOE'];
    $CONTRASENA = $_POST['CONTRASENA'];

    $consulta = "UPDATE SUPER_USUARIO SET NOMBRE = ?,  A_PATERNO= ?, A_MATERNO = ?, CORREOE = ?, CONTRASENA = ? WHERE CLAVE_SU = ?";
    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("sssssi", $NOMBRE, $A_PATERNO, $A_MATERNO, $CORREOE, $CONTRASENA, $CLAVE_SU);

        if ($stmt->execute()) {
            echo "La información se actualizó con éxito.";
        } else {
            echo "Error al Actualizar: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}

if (isset($_POST['EliminarUSUARIO'])) {
    $CLAVE_DIRECCION_ELIM = $_POST['CLAVE_SU'];
    $consulta = "DELETE FROM SUPER_USUARIO WHERE CLAVE_SU = ?";
    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("i", $CLAVE_DIRECCION_ELIM);
        if ($stmt->execute()) {
            echo "La dirección se eliminó con éxito.";
        } else {
            echo "Error al eliminar la Dirección." . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error de conexión a la base de datos: " . $conexion->error;
    }
}

$conexion->close();
?>

