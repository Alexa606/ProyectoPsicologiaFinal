<?php
    session_start();
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content = "IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CONSULTA</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" integrity="sha512-iecdLmaskl7CVkqkXNQ/ZH/XLlvWZOJyj7Yy7tcenmpD1ypASozpmT/E0iPtmFIB46ZmdtAc9eNBvH0H/ZpiBw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" type="text/css" href="estilo.css">


</head>
<body>
<form method="POST" action="conexionConsulta.php"  >
    <a href="home.php" class="menu-link">MENU</a>
                <h4>FORMULARIO CONSULTA</h4>
                
                
    <div class = "input-group">

    <div class = "input-container">
        <input type="text" name="CLAVECONSULTA" placeholder = "Clave de la consulta">
        <i class = "fa-solid fa-id-card-clip" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="MOTIVOCONSULTA" placeholder = "Motivo de la consulta">
        <i class = "fa-solid fa-comment" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="OBSERVACIONES" placeholder = "Observaciones">
        <i class = "fa-solid fa-comment" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="RECOMENDACIONES" placeholder = "Recomendaciones">
        <i class = "fa-solid fa-comment" ></i>
    </div>
    <div class = "input-container">
        <input type="text" name="PROGRESO" placeholder = "Progreso">
        <i class = "fa-solid fa-comment" ></i>
    </div>

    <input class="botons" type="submit" name = "RegistrarConsulta" value="Registrar Consulta">
    <br><br>
    <input class="botons" type="submit" name = "ActualizarConsulta" value="Actualizar Consulta">
    <br><br>
    <input class="botons" type="submit" name ="EliminarConsulta" value="Eliminar Consulta">
    
    </div>
    </form>

</body>
</html>