<?php
header('Content-Type: text/html; charset=UTF-8');

    $CLAVETUTOR = $_POST['CLAVETUTOR'];
    $NOMBRE = $_POST['NOMBRE'];
    $A_PATERNO = $_POST['A_PATERNO'];
    $A_MATERNO = $_POST['A_MATERNO'];
    $GENERO = $_POST['GENERO'];
    $EDAD = $_POST['EDAD'];
    $TELEFONOC = $_POST['TELEFONOC'];
    $CORREOE = $_POST['CORREOE'];
    $CLAVECARRERA = $_POST['CLAVECARRERA'];
    $CONTRASEÑA = $_POST['CONTRASEÑA'];

$conexion = new mysqli("127.0.0.1", "root", "", "psicologa");
$conexion->set_charset("utf8");

if ($conexion->connect_error) {
    die("Error de conexión a la base de datos: " . $conexion->connect_error);
}

if (isset($_POST['RegistrarTUTOR'])) {
    $consulta = "INSERT INTO TUTOR (CLAVETUTOR, NOMBRE, A_PATERNO, A_MATERNO, GENERO, EDAD, TELEFONOC, 
        CORREOE, CLAVECARRERA, CONTRASEÑA)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("issssissis", $CLAVETUTOR, $NOMBRE, $A_PATERNO, $A_MATERNO, $GENERO, $EDAD, $TELEFONOC,
            $CORREOE, $CLAVECARRERA, $CONTRASEÑA);

        if ($stmt->execute()) {
            echo "El tutor se registró con éxito.";
        } else {
            echo "Error al dar de alta: " . $stmt->error;
        }

    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}

if (isset($_POST['ActualizarTUTOR'])) {
    $consulta = "UPDATE TUTOR
        SET NOMBRE = ?, A_PATERNO = ?, A_MATERNO = ?, GENERO = ?, EDAD = ?, TELEFONOC = ?, 
        CORREOE = ?, CLAVECARRERA = ?, CONTRASEÑA = ?
        WHERE CLAVETUTOR = ?";
    
    $stmt = $conexion->prepare($consulta);
    
    if ($stmt) {
        $stmt->bind_param("ssssissisi", $NOMBRE, $A_PATERNO, $A_MATERNO, $GENERO, $EDAD, $TELEFONOC,
        $CORREOE, $CLAVECARRERA, $CONTRASEÑA, $CLAVETUTOR);
    
        if ($stmt->execute()) {
            echo "El tutor se actualizó con éxito.";
        } else {
            echo "Error al actualizar: " . $stmt->error;
        }
    
        $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}


if (isset($_POST['EliminarTUTOR'])) {
    $consulta = "DELETE FROM TUTOR
        WHERE CLAVETUTOR = ?";
    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("i", $CLAVETUTOR);
        if ($stmt->execute()) {
            echo "El tutor se eliminó con éxito.";
        } else {
            echo "Error al eliminar al alumno." . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error de conexión a la base de datos: " . $conexion->error;
    }
}

$conexion->close();
?>