<?php

header('Content-Type: text/html; charset=UTF-8');
include ("Alumno-Direccion.php");

$conexion = new mysqli("127.0.0.1", "root", "", "psicologa");
$conexion->set_charset("utf8");

if ($conexion->connect_error) {
    die("Error de conexión a la base de datos: " . $conexion->connect_error);
}

if (isset($_POST['RegistrarDireccion'])) {
    $CLAVE_DIRECCION = $_POST['CLAVE_DIRECCION'];
    $MUNICIPIO = $_POST['MUNICIPIO'];
    $CP = $_POST['CP'];
    $CALLE = $_POST['CALLE'];
    $NUMERO = $_POST['NUMERO'];

    $consulta = "INSERT INTO DIRECCION (CLAVE_DIRECCION, MUNICIPIO, CP, CALLE, NUMERO) VALUES (?, ?, ?, ?, ?)";
    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("isisi", $CLAVE_DIRECCION, $MUNICIPIO, $CP, $CALLE, $NUMERO);

        if ($stmt->execute()) {
            echo "La dirección se registró con éxito.";
            
        } else {
            echo "Error al registrar: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}

if (isset($_POST['ActualizarDireccion'])) {
    $CLAVE_DIRECCION_ACT = $_POST['CLAVE_DIRECCION'];
    $MUNICIPIO_ACT = $_POST['MUNICIPIO'];
    $CP_ACT = $_POST['CP'];
    $CALLE_ACT = $_POST['CALLE'];
    $NUMERO_ACT = $_POST['NUMERO'];

    $consulta = "UPDATE DIRECCION SET MUNICIPIO = ?, CP = ?, CALLE = ?, NUMERO = ? WHERE CLAVE_DIRECCION = ?";
    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("ssssi", $MUNICIPIO_ACT, $CP_ACT, $CALLE_ACT, $NUMERO_ACT, $CLAVE_DIRECCION_ACT);

        if ($stmt->execute()) {
            echo "La información se actualizó con éxito.";
        } else {
            echo "Error al Actualizar: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}

if (isset($_POST['EliminarDireccion'])) {
    $CLAVE_DIRECCION_ELIM = $_POST['CLAVE_DIRECCION'];
    $consulta = "DELETE FROM DIRECCION WHERE CLAVE_DIRECCION = ?";
    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("i", $CLAVE_DIRECCION_ELIM);
        if ($stmt->execute()) {
            echo "La dirección se eliminó con éxito.";
        } else {
            echo "Error al eliminar la Dirección." . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error de conexión a la base de datos: " . $conexion->error;
    }
}

$conexion->close();
?>

