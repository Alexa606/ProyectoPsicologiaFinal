<?php
header('Content-Type: text/html; charset=UTF-8');

$conexion = new mysqli("127.0.0.1", "root", "", "psicologa");
$conexion->set_charset("utf8"); 

if ($conexion->connect_error) {
    die("Error de conexión a la base de datos: " . $conexion->connect_error);
}

if (isset($_POST['RegistrarESTADO'])) {
    $CLAVE_ESTADO = $_POST['CLAVE_ESTADO'];
    $RIESGO = $_POST['RIESGO'];
    $NECESIDADESPECIAL = $_POST['NECESIDADESPECIAL'];
    $CANALIZADO = $_POST['CANALIZADO'];
    $DEJO_DE_ASISTIR = $_POST['DEJO_DE_ASISTIR'];
    $DUAL = $_POST['DUAL'];
    $ACCIONES = $_POST['ACCIONES'];
    $NO_CONTROL_A = $_POST['NO_CONTROL_A'];

    $consulta = "INSERT INTO ESTADO (CLAVE_ESTADO, RIESGO, NECESIDADESPECIAL, CANALIZADO, DEJO_DE_ASISTIR, `DUAL`, ACCIONES, NO_CONTROL_A)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
    
    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("issssssi", $CLAVE_ESTADO, $RIESGO, $NECESIDADESPECIAL, $CANALIZADO, $DEJO_DE_ASISTIR, $DUAL, $ACCIONES, $NO_CONTROL_A);

        if ($stmt->execute()) {
            echo "El estado se registró con éxito.";
        } else {
            echo "Error al registrar: " . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}



if (isset($_POST['ActualizarESTADO'])) {
    if ($conexion) {
        // Recopilar las variables del formulario
        $CLAVE_ESTADO = $_POST['CLAVE_ESTADO'];
        $RIESGO = $_POST['RIESGO'];
        $NECESIDADESPECIAL = $_POST['NECESIDADESPECIAL'];
        $CANALIZADO = $_POST['CANALIZADO'];
        $DEJO_DE_ASISTIR = $_POST['DEJO_DE_ASISTIR'];
        $DUAL = $_POST['DUAL'];
        $ACCIONES = $_POST['ACCIONES'];
        $NO_CONTROL_A = $_POST['NO_CONTROL_A'];

        // Preparar la consulta de actualización
        $consulta = "UPDATE ESTADO
            SET RIESGO = ?, NECESIDADESPECIAL = ?, CANALIZADO = ?, DEJO_DE_ASISTIR = ?, `DUAL` = ?, ACCIONES = ?, NO_CONTROL_A = ?
            WHERE CLAVE_ESTADO = ?";
        $stmt = $conexion->prepare($consulta);

        if ($stmt) {
            // Vincular parámetros
            $stmt->bind_param("sssssssi", $RIESGO, $NECESIDADESPECIAL, $CANALIZADO, $DEJO_DE_ASISTIR, $DUAL, $ACCIONES, $NO_CONTROL_A, $CLAVE_ESTADO);

            // Ejecutar la consulta
            if ($stmt->execute()) {
                echo "La información se actualizó con éxito.";
            } else {
                echo "Error al Actualizar: " . $stmt->error;
            }

            // Cerrar la consulta
            $stmt->close();
        } else {
            echo "Error en la preparación de la consulta: " . $conexion->error;
        }
    }
}


if (isset($_POST['EliminarESTADO'])) {
    $CLAVE_ESTADO = $_POST['CLAVE_ESTADO'];

    $consulta = "DELETE FROM ESTADO WHERE CLAVE_ESTADO = ?";
    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("i", $CLAVE_ESTADO);
        if ($stmt->execute()) {
            echo "El estado se eliminó con éxito.";
        } else {
            echo "Error al eliminar el Estado." . $stmt->error;
        }

        $stmt->close();
    } else {
        echo "Error de conexión a la base de datos: " . $conexion->error;
    }
}

$conexion->close();
?>