-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 05-12-2023 a las 07:04:44
-- Versión del servidor: 5.6.20
-- Versión de PHP: 5.5.15

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `psicologa`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `alumno`
--

CREATE TABLE IF NOT EXISTS `alumno` (
  `NO_CONTROL` int(11) NOT NULL,
  `NOMBRE` varchar(50) NOT NULL,
  `A_PATERNO` varchar(50) NOT NULL,
  `A_MATERNO` varchar(50) NOT NULL,
  `F_NACIMIENTO` date NOT NULL,
  `EDAD` int(11) NOT NULL,
  `TELEFON` varchar(20) NOT NULL,
  `CORREO_INST` varchar(100) NOT NULL,
  `GENERO` varchar(10) NOT NULL,
  `GRUPO` varchar(10) NOT NULL,
  `TURNO` varchar(20) NOT NULL,
  `SEMESTRE` int(11) NOT NULL,
  `CLAVE_DIRECCION` int(11) NOT NULL,
  `CLAVECARRERA` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `alumno`
--

INSERT INTO `alumno` (`NO_CONTROL`, `NOMBRE`, `A_PATERNO`, `A_MATERNO`, `F_NACIMIENTO`, `EDAD`, `TELEFON`, `CORREO_INST`, `GENERO`, `GRUPO`, `TURNO`, `SEMESTRE`, `CLAVE_DIRECCION`, `CLAVECARRERA`) VALUES
(1001, 'Alejandra', 'GÃ³mez', 'MartÃ­nez', '1999-05-15', 24, '555-123-4567', 'alejandra.gomez@universidad.com', 'Femenino', 'A01', 'Matutino', 3, 1, 1),
(1002, 'Roberto', 'HernÃ¡ndez', 'SÃ¡nchez', '2000-02-28', 23, '555-234-5678', 'roberto.hernandez@universidad.com', 'Masculino', 'B02', 'Vespertino', 2, 2, 2),
(1003, 'Laura', 'RodrÃ­guez', 'GarcÃ­a', '1998-09-10', 25, '555-345-6789', 'laura.rodriguez@universidad.com', 'Femenino', 'C03', 'Matutino', 4, 3, 3),
(1004, 'Carlos', 'PÃ©rez', 'LÃ³pez', '2001-07-03', 22, '555-456-7890', 'carlos.perez@universidad.com', 'Masculino', 'D04', 'Vespertino', 3, 4, 4),
(1005, 'Ana', 'GonzÃ¡lez', 'MartÃ­nez', '1999-11-20', 23, '555-567-8901', 'ana.gonzalez@universidad.com', 'Femenino', 'E05', 'Matutino', 2, 5, 5),
(1006, 'Javier', 'SÃ¡nchez', 'RamÃ­rez', '2000-04-12', 22, '555-678-9012', 'javier.sanchez@universidad.com', 'Masculino', 'F06', 'Vespertino', 4, 6, 6),
(1007, 'Mariana', 'RamÃ­rez', 'GÃ³mez', '1998-12-05', 24, '555-789-0123', 'mariana.ramirez@universidad.com', 'Femenino', 'G07', 'Matutino', 3, 7, 7),
(1008, 'Ricardo', 'LÃ³pez', 'FernÃ¡ndez', '1999-08-18', 23, '555-890-1234', 'ricardo.lopez@universidad.com', 'Masculino', 'H08', 'Vespertino', 2, 8, 8),
(1009, 'SofÃ­a', 'MartÃ­nez', 'HernÃ¡ndez', '2001-01-25', 22, '555-901-2345', 'sofia.martinez@universidad.com', 'Femenino', 'I09', 'Matutino', 4, 9, 9),
(1010, 'Diego', 'GÃ³mez', 'SÃ¡nchez', '1998-06-30', 25, '555-012-3456', 'diego.gomez@universidad.com', 'Masculino', 'J10', 'Vespertino', 3, 10, 10),
(1011, 'Elena', 'SÃ¡nchez', 'MartÃ­nez', '2000-09-03', 22, '555-123-4567', 'elena.sanchez@universidad.com', 'Femenino', 'A01', 'Matutino', 2, 11, 1),
(1012, 'Alejandro', 'GÃ³mez', 'RamÃ­rez', '1999-04-18', 23, '555-234-5678', 'alejandro.gomez@universidad.com', 'Masculino', 'B02', 'Vespertino', 4, 12, 2),
(1013, 'Carmen', 'MartÃ­nez', 'HernÃ¡ndez', '2001-11-10', 22, '555-345-6789', 'carmen.martinez@universidad.com', 'Femenino', 'C03', 'Matutino', 3, 13, 3),
(1014, 'Juan', 'HernÃ¡ndez', 'SÃ¡nchez', '1998-07-25', 24, '555-456-7890', 'juan.hernandez@universidad.com', 'Masculino', 'D04', 'Vespertino', 2, 14, 4),
(1015, 'Lorena', 'GÃ³mez', 'RamÃ­rez', '2000-12-20', 23, '555-567-8901', 'lorena.gomez@universidad.com', 'Femenino', 'E05', 'Matutino', 4, 15, 5),
(1016, 'Ricardo', 'SÃ¡nchez', 'MartÃ­nez', '1999-02-12', 25, '555-678-9012', 'ricardo.sanchez@universidad.com', 'Masculino', 'F06', 'Vespertino', 3, 16, 6),
(1017, 'MÃ³nica', 'MartÃ­nez', 'GÃ³mez', '2001-05-05', 22, '555-789-0123', 'monica.martinez@universidad.com', 'Femenino', 'G07', 'Matutino', 2, 17, 7),
(1018, 'Jorge', 'GÃ³mez', 'LÃ³pez', '1998-10-18', 23, '555-890-1234', 'jorge.gomez@universidad.com', 'Masculino', 'H08', 'Vespertino', 4, 18, 8),
(1019, 'MarÃ­a', 'LÃ³pez', 'RamÃ­rez', '2000-03-25', 22, '555-901-2345', 'maria.lopez@universidad.com', 'Femenino', 'I09', 'Matutino', 3, 19, 9),
(1020, 'Carlos', 'GonzÃ¡lez', 'SÃ¡nchez', '1999-08-30', 24, '555-012-3456', 'carlos.gonzalez@universidad.com', 'Masculino', 'J10', 'Vespertino', 2, 20, 10),
(1021, 'Ana', 'MartÃ­nez', 'FernÃ¡ndez', '2001-06-03', 22, '555-123-4567', 'ana.martinez@universidad.com', 'Femenino', 'A01', 'Matutino', 4, 21, 1),
(1022, 'Luis', 'FernÃ¡ndez', 'GÃ³mez', '1998-01-18', 23, '555-234-5678', 'luis.fernandez@universidad.com', 'Masculino', 'B02', 'Vespertino', 3, 22, 2),
(1023, 'Sara', 'GÃ³mez', 'MartÃ­nez', '2000-09-10', 25, '555-345-6789', 'sara.gomez@universidad.com', 'Femenino', 'C03', 'Matutino', 2, 23, 3),
(1024, 'Javier', 'MartÃ­nez', 'LÃ³pez', '1999-07-03', 22, '555-456-7890', 'javier.martinez@universidad.com', 'Masculino', 'D04', 'Vespertino', 4, 24, 4),
(1025, 'Elena', 'SÃ¡nchez', 'GÃ³mez', '2001-11-20', 23, '555-567-8901', 'elena.sanchez@universidad.com', 'Femenino', 'E05', 'Matutino', 3, 25, 5),
(1026, 'Roberto', 'GÃ³mez', 'HernÃ¡ndez', '1998-04-12', 22, '555-678-9012', 'roberto.gomez@universidad.com', 'Masculino', 'F06', 'Vespertino', 2, 26, 6),
(1027, 'Laura', 'MartÃ­nez', 'RamÃ­rez', '2000-12-05', 24, '555-789-0123', 'laura.martinez@universidad.com', 'Femenino', 'G07', 'Matutino', 4, 27, 7),
(1028, 'Carlos', 'SÃ¡nchez', 'FernÃ¡ndez', '1999-08-18', 23, '555-890-1234', 'carlos.sanchez@universidad.com', 'Masculino', 'H08', 'Vespertino', 3, 28, 8),
(1029, 'SofÃ­a', 'MartÃ­nez', 'HernÃ¡ndez', '2001-01-25', 22, '555-901-2345', 'sofia.martinez@universidad.com', 'Femenino', 'I09', 'Matutino', 2, 29, 9),
(1030, 'Diego', 'GÃ³mez', 'SÃ¡nchez', '1998-06-30', 25, '555-012-3456', 'diego.gomez@universidad.com', 'Masculino', 'J10', 'Vespertino', 4, 30, 10),
(1032, 'HECTOR', 'REYES', 'PEREZ', '2002-06-16', 21, '712-191-1234', 'hector.perez@universidad.com', 'Masculino', 'J10', 'Matutino', 5, 1, 1),
(1033, 'Genaro', 'Flores', 'Urbano', '2002-06-16', 21, '738-121-9876', 'genera.flores@universidad.com', 'Masculino', 'J10', 'Matutino', 5, 1, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `carrera`
--

CREATE TABLE IF NOT EXISTS `carrera` (
  `CLAVECARREA` int(11) NOT NULL,
  `CARRERA` varchar(100) NOT NULL,
  `PLANESTUDIO` varchar(50) NOT NULL,
  `CLAVEJD` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `carrera`
--

INSERT INTO `carrera` (`CLAVECARREA`, `CARRERA`, `PLANESTUDIO`, `CLAVEJD`) VALUES
(1, 'IngenierÃ­a en Sistemas', '2023-A', 101),
(2, 'Licenciatura en AdministraciÃ³n', '2023-A', 102),
(3, 'IngenierÃ­a Civil', '2023-B', 103),
(4, 'Licenciatura en PsicologÃ­a', '2023-B', 104),
(5, 'IngenierÃ­a ElÃ©ctrica', '2023-C', 105),
(6, 'Licenciatura en ContadurÃ­a', '2023-C', 106),
(7, 'Arquitectura', '2023-D', 107),
(8, 'Licenciatura en Derecho', '2023-D', 108),
(9, 'IngenierÃ­a MecÃ¡nica', '2023-E', 109),
(10, 'Licenciatura en Ciencias de la ComunicaciÃ³n', '2023-E', 110);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `cita`
--

CREATE TABLE IF NOT EXISTS `cita` (
`CLAVE_CITA` int(11) NOT NULL,
  `FECHA_HORA` datetime NOT NULL,
  `LUGAR` varchar(50) NOT NULL,
  `CORREO_INSTITUCIONAL` varchar(100) NOT NULL,
  `NO_CONTROL_ALUMNO` int(11) NOT NULL,
  `CLAVECONSULTA` int(11) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=31 ;

--
-- Volcado de datos para la tabla `cita`
--

INSERT INTO `cita` (`CLAVE_CITA`, `FECHA_HORA`, `LUGAR`, `CORREO_INSTITUCIONAL`, `NO_CONTROL_ALUMNO`, `CLAVECONSULTA`) VALUES
(1, '2023-05-10 14:00:00', 'Sala de reuniones 1', 'alejandra.gomez@universidad.com', 1001, 1),
(2, '2023-05-12 15:30:00', 'Aula 203', 'roberto.hernandez@universidad.com', 1002, 2),
(3, '2023-05-15 10:45:00', 'Biblioteca', 'laura.rodriguez@universidad.com', 1003, 3),
(4, '2023-05-18 13:20:00', 'Sala de profesores', 'carlos.perez@universidad.com', 1004, 4),
(5, '2023-05-20 16:00:00', 'Laboratorio de informÃ¡tica', 'ana.gonzalez@universidad.com', 1005, 5),
(6, '2023-05-23 11:30:00', 'Aula 105', 'javier.sanchez@universidad.com', 1006, 6),
(7, '2023-05-25 14:45:00', 'Sala de reuniones 2', 'mariana.ramirez@universidad.com', 1007, 7),
(8, '2023-05-28 10:00:00', 'Sala de profesores', 'ricardo.lopez@universidad.com', 1008, 8),
(9, '2023-05-30 15:15:00', 'Biblioteca', 'sofia.martinez@universidad.com', 1009, 9),
(10, '2023-06-02 12:30:00', 'Aula 205', 'diego.gomez@universidad.com', 1010, 10),
(11, '2023-06-05 14:00:00', 'Sala de reuniones 1', 'elena.sanchez@universidad.com', 1011, 11),
(12, '2023-06-08 15:30:00', 'Aula 203', 'alejandro.gomez@universidad.com', 1012, 12),
(13, '2023-06-11 10:45:00', 'Biblioteca', 'carmen.martinez@universidad.com', 1013, 13),
(14, '2023-06-14 13:20:00', 'Sala de profesores', 'juan.hernandez@universidad.com', 1014, 14),
(15, '2023-06-17 16:00:00', 'Laboratorio de informÃ¡tica', 'lorena.gomez@universidad.com', 1015, 15),
(16, '2023-06-20 11:30:00', 'Aula 105', 'ricardo.sanchez@universidad.com', 1016, 16),
(17, '2023-06-23 14:45:00', 'Sala de reuniones 2', 'monica.martinez@universidad.com', 1017, 17),
(18, '2023-06-26 10:00:00', 'Sala de profesores', 'jorge.gomez@universidad.com', 1018, 18),
(19, '2023-06-29 15:15:00', 'Biblioteca', 'maria.lopez@universidad.com', 1019, 19),
(20, '2023-07-02 12:30:00', 'Aula 205', 'carlos.gonzalez@universidad.com', 1020, 20),
(21, '2023-07-05 14:00:00', 'Sala de reuniones 1', 'ana.martinez@universidad.com', 1021, 21),
(22, '2023-07-08 15:30:00', 'Aula 203', 'luis.fernandez@universidad.com', 1022, 22),
(23, '2023-07-11 10:45:00', 'Biblioteca', 'sara.gomez@universidad.com', 1023, 23),
(24, '2023-07-14 13:20:00', 'Sala de profesores', 'javier.martinez@universidad.com', 1024, 24),
(25, '2023-07-17 16:00:00', 'Laboratorio de informÃ¡tica', 'elena.sanchez@universidad.com', 1025, 25),
(26, '2023-07-20 11:30:00', 'Aula 105', 'roberto.gomez@universidad.com', 1026, 26),
(27, '2023-07-23 14:45:00', 'Sala de reuniones 2', 'laura.martinez@universidad.com', 1027, 27),
(28, '2023-07-26 10:00:00', 'Sala de profesores', 'carlos.sanchez@universidad.com', 1028, 28),
(29, '2023-07-29 15:15:00', 'Biblioteca', 'sofia.martinez@universidad.com', 1029, 29),
(30, '2023-08-01 12:30:00', 'Aula 205', 'diego.gomez@universidad.com', 1030, 30);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `consulta`
--

CREATE TABLE IF NOT EXISTS `consulta` (
`CLAVECONSULTA` int(11) NOT NULL,
  `MOTIVOCONSULTA` varchar(200) NOT NULL,
  `OBSERVACIONES` varchar(500) NOT NULL,
  `RECOMENDACIONES` varchar(500) NOT NULL,
  `PROGRESO` varchar(500) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=31 ;

--
-- Volcado de datos para la tabla `consulta`
--

INSERT INTO `consulta` (`CLAVECONSULTA`, `MOTIVOCONSULTA`, `OBSERVACIONES`, `RECOMENDACIONES`, `PROGRESO`) VALUES
(1, 'Problemas de concentraciÃ³n', 'El estudiante se muestra distraÃ­do en clase', 'Reforzar tÃ©cnicas de concentraciÃ³n', 'En proceso'),
(2, 'Dificultades en matemÃ¡ticas', 'El estudiante tiene problemas con los conceptos bÃ¡sicos', 'Clases de refuerzo en matemÃ¡ticas', 'Mejorando'),
(3, 'Ansiedad antes de exÃ¡menes', 'El estudiante reporta nerviosismo y ansiedad previo a los exÃ¡menes', 'Aplicar tÃ©cnicas de manejo del estrÃ©s', 'Progresando'),
(4, 'Bajo rendimiento acadÃ©mico', 'El estudiante presenta bajos resultados en varias asignaturas', 'DiseÃ±ar plan de estudios personalizado', 'En proceso'),
(5, 'Problemas de lectura', 'El estudiante tiene dificultades para comprender textos', 'Implementar actividades de lectura guiada', 'Mejorando'),
(6, 'Falta de participaciÃ³n en clase', 'El estudiante muestra reluctancia para participar en discusiones', 'Fomentar la participaciÃ³n activa', 'Progresando'),
(7, 'DesmotivaciÃ³n acadÃ©mica', 'El estudiante manifiesta falta de interÃ©s en las asignaturas', 'Buscar actividades que despierten interÃ©s', 'Mejorando'),
(8, 'Problemas de organizaciÃ³n', 'El estudiante tiene dificultades para organizar sus tareas', 'Brindar herramientas de organizaciÃ³n', 'En proceso'),
(9, 'Dificultades en redacciÃ³n', 'El estudiante presenta problemas en la expresiÃ³n escrita', 'Realizar ejercicios de redacciÃ³n', 'Progresando'),
(10, 'Falta de hÃ¡bitos de estudio', 'El estudiante no tiene hÃ¡bitos de estudio establecidos', 'Crear rutinas de estudio', 'Mejorando'),
(11, 'Problemas de conducta', 'El estudiante muestra comportamientos disruptivos en clase', 'Implementar estrategias de manejo de conducta', 'Progresando'),
(12, 'Baja autoestima acadÃ©mica', 'El estudiante duda de sus habilidades acadÃ©micas', 'Fomentar la autoconfianza', 'Mejorando'),
(13, 'Falta de interacciÃ³n social', 'El estudiante tiene dificultades para relacionarse con sus compaÃ±eros', 'Facilitar actividades grupales', 'Progresando'),
(14, 'Dificultades en la resoluciÃ³n de problemas', 'El estudiante encuentra dificultades en la resoluciÃ³n de ejercicios', 'Practicar problemas similares', 'Mejorando'),
(15, 'Problemas de adaptaciÃ³n', 'El estudiante es nuevo y tiene dificultades para adaptarse', 'Brindar apoyo emocional y acadÃ©mico', 'Progresando'),
(16, 'Falta de asistencia', 'El estudiante ha faltado frecuentemente a clases', 'Investigar las razones de las ausencias', 'En proceso'),
(17, 'Problemas de salud', 'El estudiante presenta problemas de salud que afectan su rendimiento', 'Coordinar con servicios mÃ©dicos de la instituciÃ³n', 'Progresando'),
(18, 'Dificultades en la comprensiÃ³n lectora', 'El estudiante tiene problemas para entender textos complejos', 'Implementar estrategias de lectura comprensiva', 'Mejorando'),
(19, 'Falta de material didÃ¡ctico', 'El estudiante carece de recursos educativos', 'Proporcionar material de apoyo', 'En proceso'),
(20, 'Problemas de comunicaciÃ³n', 'El estudiante tiene dificultades para expresarse claramente', 'Fomentar la expresiÃ³n oral', 'Progresando'),
(21, 'Falta de participaciÃ³n en actividades extracurriculares', 'El estudiante no participa en actividades fuera de clase', 'Promover la participaciÃ³n en clubes y eventos', 'Mejorando'),
(22, 'Dificultades en la comprensiÃ³n de instrucciones', 'El estudiante tiene problemas para seguir instrucciones', 'Explicar instrucciones de manera detallada', 'Progresando'),
(23, 'Problemas de memoria', 'El estudiante olvida informaciÃ³n importante', 'Utilizar tÃ©cnicas de memoria y recordatorio', 'En proceso'),
(24, 'Falta de interÃ©s en la carrera', 'El estudiante duda de su elecciÃ³n de carrera', 'Explorar opciones de orientaciÃ³n vocacional', 'Progresando'),
(25, 'Problemas de atenciÃ³n', 'El estudiante se distrae fÃ¡cilmente en clase', 'Implementar estrategias para mantener la atenciÃ³n', 'Mejorando'),
(26, 'Falta de participaciÃ³n en proyectos grupales', 'El estudiante no colabora en proyectos en equipo', 'Fomentar la colaboraciÃ³n y trabajo en equipo', 'Progresando'),
(27, 'Problemas familiares', 'El estudiante enfrenta dificultades en el Ã¡mbito familiar', 'Ofrecer apoyo emocional y recursos', 'En proceso'),
(28, 'Falta de motivaciÃ³n para el autoaprendizaje', 'El estudiante no busca aprender de manera autÃ³noma', 'Promover el interÃ©s por el autoaprendizaje', 'Progresando'),
(29, 'Problemas financieros', 'El estudiante enfrenta dificultades econÃ³micas', 'Conectar con servicios de apoyo financiero', 'En proceso'),
(30, 'Falta de habilidades de comunicaciÃ³n', 'El estudiante tiene dificultades para expresarse con claridad', 'Desarrollar habilidades de comunicaciÃ³n oral y escrita', 'Progresando');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `direccion`
--

CREATE TABLE IF NOT EXISTS `direccion` (
`CLAVE_DIRECCION` int(11) NOT NULL,
  `MUNICIPIO` varchar(50) NOT NULL,
  `CP` int(11) NOT NULL,
  `CALLE` varchar(50) NOT NULL,
  `NUMERO` int(11) DEFAULT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=31 ;

--
-- Volcado de datos para la tabla `direccion`
--

INSERT INTO `direccion` (`CLAVE_DIRECCION`, `MUNICIPIO`, `CP`, `CALLE`, `NUMERO`) VALUES
(1, 'Ciudad de MÃ©xico', 7000, 'Av. Reforma', 123),
(2, 'Guadalajara', 44100, 'Calle JuÃ¡rez', 456),
(3, 'Monterrey', 64000, 'Av. ConstituciÃ³n', 789),
(4, 'Puebla', 72000, 'Calle 5 de Mayo', 101),
(5, 'QuerÃ©taro', 76000, 'Blvd. Bernardo Quintana', 202),
(6, 'Tijuana', 22000, 'Av. RevoluciÃ³n', 303),
(7, 'LeÃ³n', 37000, 'Calle Madero', 404),
(8, 'CancÃºn', 77500, 'Blvd. KukulcÃ¡n', 505),
(9, 'Merida', 97000, 'Calle 60', 606),
(10, 'Acapulco', 39350, 'Av. Costera Miguel AlemÃ¡n', 707),
(11, 'Toluca', 50000, 'Paseo Tollocan', 808),
(12, 'Chihuahua', 31000, 'Av. TecnolÃ³gico', 909),
(13, 'Morelia', 58000, 'Calle Galeana', 1010),
(14, 'Aguascalientes', 20000, 'Av. LÃ³pez Mateos', 1111),
(15, 'CuliacÃ¡n', 80000, 'Blvd. Sinaloa', 1212),
(16, 'Hermosillo', 83000, 'Calle Rosales', 1313),
(17, 'Saltillo', 25000, 'Av. Venustiano Carranza', 1414),
(18, 'Tuxtla GutiÃ©rrez', 29000, 'Blvd. Belisario DomÃ­nguez', 1515),
(19, 'Durango', 34000, 'Calle 20 de Noviembre', 1616),
(20, 'Tepic', 63150, 'Av. MÃ©xico', 1717),
(21, 'Villahermosa', 86000, 'Paseo Usumacinta', 1818),
(22, 'Campeche', 24000, 'Calle 59', 1919),
(23, 'Colima', 28000, 'Av. Felipe Sevilla', 2020),
(24, 'La Paz', 23000, 'Calle 16 de Septiembre', 2121),
(25, 'Tlaxcala', 90000, 'Av. JuÃ¡rez', 2222),
(26, 'Xalapa', 91000, 'Calle EnrÃ­quez', 2323),
(27, 'Zacatecas', 98000, 'Av. Hidalgo', 2424),
(28, 'Cuernavaca', 62000, 'Calle Matamoros', 2525),
(29, 'Toluca', 50130, 'Av. Independencia', 2626),
(30, 'Oaxaca', 68000, 'Calle Macedonio AlcalÃ¡', 2727);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `estado`
--

CREATE TABLE IF NOT EXISTS `estado` (
`CLAVE_ESTADO` int(11) NOT NULL,
  `RIESGO` varchar(30) NOT NULL,
  `NECESIDADESPECIAL` varchar(30) NOT NULL,
  `CANALIZADO` varchar(50) NOT NULL,
  `DEJO_DE_ASISTIR` varchar(30) NOT NULL,
  `DUAL` varchar(30) NOT NULL,
  `ACCIONES` text NOT NULL,
  `NO_CONTROL_A` int(11) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=31 ;

--
-- Volcado de datos para la tabla `estado`
--

INSERT INTO `estado` (`CLAVE_ESTADO`, `RIESGO`, `NECESIDADESPECIAL`, `CANALIZADO`, `DEJO_DE_ASISTIR`, `DUAL`, `ACCIONES`, `NO_CONTROL_A`) VALUES
(1, 'Segundas', 'Ninguna', 'SÃ­', 'No', 'No', 'Reforzar temario de las clases', 1001),
(2, 'Especial', 'Dislexia', 'SÃ­', 'SÃ­', 'SÃ­', 'Apoyo con profesor especializado', 1002),
(3, 'Recurse', 'Ninguna', 'No', 'No', 'No', 'Clases de refuerzo durante el semestre', 1003),
(4, 'Ninguna', 'Ninguna', 'SÃ­', 'No', 'No', 'RevisiÃ³n de temario con tutor', 1004),
(5, 'Segundas', 'DÃ©ficit de atenciÃ³n', 'SÃ­', 'SÃ­', 'No', 'Uso de tÃ©cnicas de estudio especÃ­ficas', 1005),
(6, 'Especial', 'Autismo', 'No', 'No', 'SÃ­', 'AdaptaciÃ³n de materiales y evaluaciones', 1006),
(7, 'Recurse', 'Ninguna', 'SÃ­', 'No', 'No', 'TutorÃ­as para reforzar conocimientos previos', 1007),
(8, 'Ninguna', 'Ninguna', 'No', 'No', 'No', 'Seguimiento regular con el tutor', 1008),
(9, 'Segundas', 'Discalculia', 'SÃ­', 'No', 'No', 'Apoyo de un mentor acadÃ©mico', 1009),
(10, 'Especial', 'SÃ­ndrome de Down', 'SÃ­', 'SÃ­', 'SÃ­', 'AdaptaciÃ³n de actividades y evaluaciones', 1010),
(11, 'Recurse', 'Ninguna', 'No', 'No', 'No', 'Asistencia a clases de repaso', 1011),
(12, 'Ninguna', 'Ninguna', 'SÃ­', 'No', 'No', 'Reforzar hÃ¡bitos de estudio', 1012),
(13, 'Segundas', 'Dificultades de aprendizaje', 'SÃ­', 'SÃ­', 'No', 'Plan de apoyo individualizado', 1013),
(14, 'Especial', 'DÃ©ficit de atenciÃ³n', 'SÃ­', 'No', 'SÃ­', 'AdaptaciÃ³n de tiempos de evaluaciÃ³n', 1014),
(15, 'Recurse', 'Ninguna', 'No', 'No', 'No', 'ParticipaciÃ³n en programas de tutorÃ­as', 1015),
(16, 'Ninguna', 'Ninguna', 'SÃ­', 'No', 'No', 'Seguimiento de avance acadÃ©mico', 1016),
(17, 'Segundas', 'Dislexia', 'SÃ­', 'SÃ­', 'No', 'Uso de tecnologÃ­as de apoyo', 1017),
(18, 'Especial', 'Autismo', 'No', 'No', 'SÃ­', 'AdaptaciÃ³n de evaluaciones y exÃ¡menes', 1018),
(19, 'Recurse', 'Ninguna', 'SÃ­', 'No', 'No', 'Clases de refuerzo en materias especÃ­ficas', 1019),
(20, 'Ninguna', 'Ninguna', 'No', 'No', 'No', 'Monitoreo constante de asistencia', 1020),
(21, 'Segundas', 'DÃ©ficit de atenciÃ³n', 'SÃ­', 'SÃ­', 'No', 'Apoyo de un mentor acadÃ©mico', 1021),
(22, 'Especial', 'SÃ­ndrome de Down', 'SÃ­', 'SÃ­', 'SÃ­', 'AdaptaciÃ³n de actividades y evaluaciones', 1022),
(23, 'Recurse', 'Ninguna', 'No', 'No', 'No', 'Asistencia a clases de repaso', 1023),
(24, 'Ninguna', 'Ninguna', 'SÃ­', 'No', 'No', 'Reforzar hÃ¡bitos de estudio', 1024),
(25, 'Segundas', 'Dificultades de aprendizaje', 'SÃ­', 'SÃ­', 'No', 'Plan de apoyo individualizado', 1025),
(26, 'Especial', 'DÃ©ficit de atenciÃ³n', 'SÃ­', 'No', 'SÃ­', 'AdaptaciÃ³n de tiempos de evaluaciÃ³n', 1026),
(27, 'Recurse', 'Ninguna', 'No', 'No', 'No', 'ParticipaciÃ³n en programas de tutorÃ­as', 1027),
(28, 'Ninguna', 'Ninguna', 'SÃ­', 'No', 'No', 'Seguimiento de avance acadÃ©mico', 1028),
(29, 'Segundas', 'Dislexia', 'SÃ­', 'SÃ­', 'No', 'Uso de tecnologÃ­as de apoyo', 1029),
(30, 'Especial', 'Autismo', 'No', 'No', 'SÃ­', 'AdaptaciÃ³n de evaluaciones y exÃ¡menes', 1030);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `jefe_de_division`
--

CREATE TABLE IF NOT EXISTS `jefe_de_division` (
  `CLAVEJD` int(11) NOT NULL,
  `NOMBRE` varchar(50) NOT NULL,
  `A_PATERNO` varchar(50) NOT NULL,
  `A_MATERNO` varchar(50) NOT NULL,
  `GENERO` varchar(20) NOT NULL,
  `EDAD` int(11) NOT NULL,
  `TELEFONOC` varchar(20) NOT NULL,
  `CORREOE` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `jefe_de_division`
--

INSERT INTO `jefe_de_division` (`CLAVEJD`, `NOMBRE`, `A_PATERNO`, `A_MATERNO`, `GENERO`, `EDAD`, `TELEFONOC`, `CORREOE`) VALUES
(101, 'Juan', 'GÃ³mez', 'LÃ³pez', 'Masculino', 45, '555-123-4567', 'juan.gomez@email.com'),
(102, 'MarÃ­a', 'HernÃ¡ndez', 'MartÃ­nez', 'Femenino', 38, '555-234-5678', 'maria.hernandez@email.com'),
(103, 'Carlos', 'RodrÃ­guez', 'SÃ¡nchez', 'Masculino', 50, '555-345-6789', 'carlos.rodriguez@email.com'),
(104, 'Laura', 'PÃ©rez', 'GarcÃ­a', 'Femenino', 42, '555-456-7890', 'laura.perez@email.com'),
(105, 'Javier', 'DÃ­az', 'RamÃ­rez', 'Masculino', 48, '555-567-8901', 'javier.diaz@email.com'),
(106, 'Isabel', 'MartÃ­nez', 'GonzÃ¡lez', 'Femenino', 37, '555-678-9012', 'isabel.martinez@email.com'),
(107, 'Miguel', 'LÃ³pez', 'FernÃ¡ndez', 'Masculino', 55, '555-789-0123', 'miguel.lopez@email.com'),
(108, 'Ana', 'GarcÃ­a', 'JimÃ©nez', 'Femenino', 40, '555-890-1234', 'ana.garcia@email.com'),
(109, 'Pedro', 'SÃ¡nchez', 'Ruiz', 'Masculino', 43, '555-901-2345', 'pedro.sanchez@email.com'),
(110, 'Carmen', 'FernÃ¡ndez', 'Torres', 'Femenino', 39, '555-012-3456', 'carmen.fernandez@email.com');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `super_usuario`
--

CREATE TABLE IF NOT EXISTS `super_usuario` (
  `CLAVE_SU` int(11) NOT NULL,
  `NOMBRE` varchar(50) NOT NULL,
  `A_PATERNO` varchar(50) NOT NULL,
  `A_MATERNO` varchar(50) NOT NULL,
  `CORREOE` varchar(100) NOT NULL,
  `CONTRASENA` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `super_usuario`
--

INSERT INTO `super_usuario` (`CLAVE_SU`, `NOMBRE`, `A_PATERNO`, `A_MATERNO`, `CORREOE`, `CONTRASENA`) VALUES
(5001, 'Jose', 'Zuñiga', 'Sandoval', 'jose.zuñiga@universidad.com', 'jose123');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tutor`
--

CREATE TABLE IF NOT EXISTS `tutor` (
  `CLAVETUTOR` int(11) NOT NULL,
  `NOMBRE` varchar(50) NOT NULL,
  `A_PATERNO` varchar(50) NOT NULL,
  `A_MATERNO` varchar(50) NOT NULL,
  `GENERO` varchar(20) NOT NULL,
  `EDAD` int(11) NOT NULL,
  `TELEFONOC` varchar(20) NOT NULL,
  `CORREOE` varchar(100) NOT NULL,
  `CLAVECARRERA` int(11) NOT NULL,
  `CONTRASEÑA` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Volcado de datos para la tabla `tutor`
--

INSERT INTO `tutor` (`CLAVETUTOR`, `NOMBRE`, `A_PATERNO`, `A_MATERNO`, `GENERO`, `EDAD`, `TELEFONOC`, `CORREOE`, `CLAVECARRERA`, `CONTRASEÑA`) VALUES
(201, 'Elena', 'GonzÃ¡lez', 'MartÃ­nez', 'Femenino', 34, '555-123-4567', 'elena.gonzalez@email.com', 1, 'tutorElena123'),
(202, 'Ricardo', 'DÃ­az', 'Vargas', 'Masculino', 42, '555-234-5678', 'ricardo.diaz@email.com', 2, 'tutorRicardo456'),
(203, 'Laura', 'RamÃ­rez', 'HernÃ¡ndez', 'Femenino', 37, '555-345-6789', 'laura.ramirez@email.com', 3, 'tutorLaura789'),
(204, 'Carlos', 'SÃ¡nchez', 'LÃ³pez', 'Masculino', 45, '555-456-7890', 'carlos.sanchez@email.com', 4, 'tutorCarlos101'),
(205, 'Ana', 'GarcÃ­a', 'FernÃ¡ndez', 'Femenino', 39, '555-567-8901', 'ana.garcia@email.com', 5, 'tutorAna202'),
(206, 'Javier', 'MartÃ­nez', 'GÃ³mez', 'Masculino', 48, '555-678-9012', 'javier.martinez@email.com', 6, 'tutorJavier303'),
(207, 'Sara', 'FernÃ¡ndez', 'GÃ³mez', 'Femenino', 36, '555-789-0123', 'sara.fernandez@email.com', 7, 'tutorSara404'),
(208, 'Miguel', 'LÃ³pez', 'HernÃ¡ndez', 'Masculino', 50, '555-890-1234', 'miguel.lopez@email.com', 8, 'tutorMiguel505'),
(209, 'Isabel', 'DÃ­az', 'RamÃ­rez', 'Femenino', 41, '555-901-2345', 'isabel.diaz@email.com', 9, 'tutorIsabel606'),
(210, 'Diego', 'GÃ³mez', 'SÃ¡nchez', 'Masculino', 44, '555-012-3456', 'diego.gomez@email.com', 10, 'tutorDiego707'),
(211, 'Luis', 'MartÃ­nez', 'GÃ³mez', 'Masculino', 38, '555-123-4567', 'luis.martinez@email.com', 1, 'tutorLuis123'),
(212, 'Carmen', 'GonzÃ¡lez', 'HernÃ¡ndez', 'Femenino', 35, '555-234-5678', 'carmen.gonzalez@email.com', 2, 'tutorCarmen456'),
(213, 'RaÃºl', 'RamÃ­rez', 'SÃ¡nchez', 'Masculino', 47, '555-345-6789', 'raul.ramirez@email.com', 3, 'tutorRaul789'),
(214, 'Elena', 'DÃ­az', 'LÃ³pez', 'Femenino', 40, '555-456-7890', 'elena.diaz@email.com', 4, 'tutorElena101'),
(215, 'Juan', 'FernÃ¡ndez', 'GÃ³mez', 'Masculino', 43, '555-567-8901', 'juan.fernandez@email.com', 5, 'tutorJuan202'),
(216, 'Lorena', 'SÃ¡nchez', 'MartÃ­nez', 'Femenino', 36, '555-678-9012', 'lorena.sanchez@email.com', 6, 'tutorLorena303'),
(217, 'Miguel', 'GÃ³mez', 'RamÃ­rez', 'Masculino', 49, '555-789-0123', 'miguel.gomez@email.com', 7, 'tutorMiguel404'),
(218, 'SofÃ­a', 'HernÃ¡ndez', 'LÃ³pez', 'Femenino', 42, '555-890-1234', 'sofia.hernandez@email.com', 8, 'tutorSofia505'),
(219, 'Arturo', 'MartÃ­nez', 'DÃ­az', 'Masculino', 39, '555-901-2345', 'arturo.martinez@email.com', 9, 'tutorArturo606'),
(220, 'Ana', 'DÃ­az', 'FernÃ¡ndez', 'Femenino', 41, '555-012-3456', 'ana.diaz@email.com', 10, 'tutorAna707');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `alumno`
--
ALTER TABLE `alumno`
 ADD PRIMARY KEY (`NO_CONTROL`), ADD KEY `carrera_alumno` (`CLAVECARRERA`), ADD KEY `carrera_direccion` (`CLAVE_DIRECCION`);

--
-- Indices de la tabla `carrera`
--
ALTER TABLE `carrera`
 ADD PRIMARY KEY (`CLAVECARREA`), ADD KEY `carrera_jd` (`CLAVEJD`);

--
-- Indices de la tabla `cita`
--
ALTER TABLE `cita`
 ADD PRIMARY KEY (`CLAVE_CITA`), ADD KEY `alumno_cita` (`NO_CONTROL_ALUMNO`), ADD KEY `consulta_cita` (`CLAVECONSULTA`);

--
-- Indices de la tabla `consulta`
--
ALTER TABLE `consulta`
 ADD PRIMARY KEY (`CLAVECONSULTA`);

--
-- Indices de la tabla `direccion`
--
ALTER TABLE `direccion`
 ADD PRIMARY KEY (`CLAVE_DIRECCION`);

--
-- Indices de la tabla `estado`
--
ALTER TABLE `estado`
 ADD PRIMARY KEY (`CLAVE_ESTADO`), ADD KEY `alumno_estado` (`NO_CONTROL_A`);

--
-- Indices de la tabla `jefe_de_division`
--
ALTER TABLE `jefe_de_division`
 ADD PRIMARY KEY (`CLAVEJD`);

--
-- Indices de la tabla `super_usuario`
--
ALTER TABLE `super_usuario`
 ADD PRIMARY KEY (`CLAVE_SU`);

--
-- Indices de la tabla `tutor`
--
ALTER TABLE `tutor`
 ADD PRIMARY KEY (`CLAVETUTOR`), ADD KEY `carrera_tutor` (`CLAVECARRERA`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `cita`
--
ALTER TABLE `cita`
MODIFY `CLAVE_CITA` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT de la tabla `consulta`
--
ALTER TABLE `consulta`
MODIFY `CLAVECONSULTA` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT de la tabla `direccion`
--
ALTER TABLE `direccion`
MODIFY `CLAVE_DIRECCION` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT de la tabla `estado`
--
ALTER TABLE `estado`
MODIFY `CLAVE_ESTADO` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=31;
--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `alumno`
--
ALTER TABLE `alumno`
ADD CONSTRAINT `carrera_alumno` FOREIGN KEY (`CLAVECARRERA`) REFERENCES `carrera` (`CLAVECARREA`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `carrera_direccion` FOREIGN KEY (`CLAVE_DIRECCION`) REFERENCES `direccion` (`CLAVE_DIRECCION`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `carrera`
--
ALTER TABLE `carrera`
ADD CONSTRAINT `carrera_jd` FOREIGN KEY (`CLAVEJD`) REFERENCES `jefe_de_division` (`CLAVEJD`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `cita`
--
ALTER TABLE `cita`
ADD CONSTRAINT `alumno_cita` FOREIGN KEY (`NO_CONTROL_ALUMNO`) REFERENCES `alumno` (`NO_CONTROL`) ON DELETE NO ACTION ON UPDATE NO ACTION,
ADD CONSTRAINT `consulta_cita` FOREIGN KEY (`CLAVECONSULTA`) REFERENCES `consulta` (`CLAVECONSULTA`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `estado`
--
ALTER TABLE `estado`
ADD CONSTRAINT `alumno_estado` FOREIGN KEY (`NO_CONTROL_A`) REFERENCES `alumno` (`NO_CONTROL`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `tutor`
--
ALTER TABLE `tutor`
ADD CONSTRAINT `carrera_tutor` FOREIGN KEY (`CLAVECARRERA`) REFERENCES `carrera` (`CLAVECARREA`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
