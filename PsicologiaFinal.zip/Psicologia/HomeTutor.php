<?php
    session_start();

    if (!isset($_SESSION['usuario'])) {
        // Redirigir a la página de inicio de sesión
        header("Location: index.php");
        exit();
    }
    $nombre=$_SESSION['nombre'];
    $apellido=$_SESSION['a_paterno'];
    $nombre=strtoupper($nombre);
    $apellido=strtoupper($apellido);
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Departamento Psicologia</title>
    <link rel="stylesheet" href="MenuTu.css">
</head>
<body>
    <header class="header">
        <div class="logo">INFORME A DEPARTAMENTO DE PSICOLOGIA</div>
        <input type="checkbox" id = "toggle">
        <label for="toggle"> <img class="menu" src="images/menu.svg" alt="menu"></label>
        <nav class="navegation">

            <ul>
                <li><a href="#">FORMULARIOS</a>
                    <ul>
                         <li><a href="http://localhost/Psicologia/Alumno-Direccion.php">ALUMNOS</a></li>
                         <li><a href="http://localhost/Psicologia/Estados.php">ESTADO</a></li>
                    </ul>
                </li>
                <li><a href="#">TUTOR <?php echo $nombre." ".$apellido;?></a>
                    <ul>
                        <li><a href="logout.php">CERRAR SESIÓN</a></li>                       
                    </ul>
                </li>
            </ul>
        </nav>
    </header>
    <div class="hero"></div>
</body>
</html>