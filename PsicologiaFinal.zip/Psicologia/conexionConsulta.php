<?php
header('Content-Type: text/html; charset=UTF-8');
$CLAVECONSULTA = $_POST['CLAVECONSULTA'];
$MOTIVOCONSULTA = $_POST['MOTIVOCONSULTA'];
$OBSERVACIONES = $_POST['OBSERVACIONES'];
$RECOMENDACIONES = $_POST['RECOMENDACIONES'];
$PROGRESO = $_POST['PROGRESO'];

$conexion = new mysqli("127.0.0.1", "root", "", "psicologa");
$conexion->set_charset("utf8");

if ($conexion->connect_error) {
    die("Error de conexión a la base de datos: " . $conexion->connect_error);
}

if (isset($_POST['RegistrarConsulta'])) {
    $consulta = "INSERT INTO CONSULTA (CLAVECONSULTA, MOTIVOCONSULTA, OBSERVACIONES, RECOMENDACIONES, PROGRESO)
                VALUES (?, ?, ?, ?, ?)";

    $stmt = $conexion->prepare($consulta);

    if ($stmt) {
        $stmt->bind_param("sssss", $CLAVECONSULTA, $MOTIVOCONSULTA, $OBSERVACIONES, $RECOMENDACIONES, $PROGRESO);

        if ($stmt->execute()) {
            echo "La Consulta se registró con éxito.";
        } else {
            echo "Error al dar de alta: " . $stmt->error;
        }

    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}

if (isset($_POST['ActualizarConsulta'])) {
    $consulta = "UPDATE CONSULTA 
        SET MOTIVOCONSULTA = ?, OBSERVACIONES = ?, RECOMENDACIONES = ?, PROGRESO = ?
        WHERE CLAVECONSULTA = ?";
    
    $stmt = $conexion->prepare($consulta);
    
    if ($stmt) {
        $stmt->bind_param("sssss", $MOTIVOCONSULTA, $OBSERVACIONES, $RECOMENDACIONES, $PROGRESO, $CLAVECONSULTA);
    
        if ($stmt->execute()) {
            echo "La actualización se realizó con éxito.";
        } else {
            echo "Error al actualizar la Consulta: " . $stmt->error;
        }
    
        $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}

if (isset($_POST['EliminarConsulta'])) {
    $consulta = "DELETE FROM CONSULTA
        WHERE CLAVECONSULTA = ?";
    
    $stmt = $conexion->prepare($consulta);
    
    if ($stmt) {
        $stmt->bind_param("s", $CLAVECONSULTA);
    
        if ($stmt->execute()) {
            echo "La consulta se eliminó con éxito.";
        } else {
            echo "Error al eliminar la Consulta: " . $stmt->error;
        }
    
        $stmt->close();
    } else {
        echo "Error en la preparación de la consulta: " . $conexion->error;
    }
}

$conexion->close();
?>
