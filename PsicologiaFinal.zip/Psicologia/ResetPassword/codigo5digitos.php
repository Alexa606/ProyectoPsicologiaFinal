<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="estilosRecovery.css">
    <title>Document</title>
</head>

<header>
    <div class="logo">
        <img class="logo-img" src="images/LogoTec.jpg" alt="tesJO">
        <h2 class="title">Departamento de Psicología</h2>
        <img src="images/logo-psicologia.png" alt="psi">
    </div>
</header>

<body>
    <h1>Datos del Usuario</h1>
    <p>Nombre: <?php echo $nombre; ?></p>
    <p>Apellido Paterno: <?php echo $apellidoPaterno; ?></p>
    <div class="container">
        <form action="validarToken.php" method="POST">
            <h2 class="tittleRec" justify-content="center">Codigo de Seguridad</h2>
            <div class="form-group">
                <input type="text" class="form-control" name="recoverytoken" placeholder="Introduce el codigo de 5 dígitos" >
            </div>
            <button type="submit" class="btn btn-primary" name="intoCodigo">Ingresar Codigo</button>
        </form>
    </div>
</body>
</html>