<?php

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Cargar la biblioteca PHPMailer
require 'PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';

require 'vendor/autoload.php';

$conexion = new mysqli("127.0.0.1", "root", "", "psicologa");
$conexion->set_charset("utf8");

$correo=$_POST['correo'];
$TIPO_USUARIO=$_POST['TIPO_USUARIO'];
$codigo=rand(00000,99999);

if($TIPO_USUARIO=='psicologo'){
    
    if(isset($_POST['enviarCodigo'])){
        $consulta="SELECT NOMBRE, A_PATERNO FROM SUPER_USUARIO WHERE CORREOE=?";
        $stmt=$conexion->prepare($consulta);

        if ($stmt) {
            $stmt->bind_param("s",$correo);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $filas = $resultado->fetch_assoc();
        
            if ($filas) {
                $nombre = $filas['NOMBRE'];
                $apellidoPaterno = $filas['A_PATERNO'];

                $query="UPDATE SUPER_USUARIO SET TOKEN=? WHERE CORREOE=?";
                $stdi=$conexion->prepare($query);
                $stdi->bind_param("is",$codigo,$correo);
                $stdi->execute();
                $result=$stdi->get_result();

                $mail = new PHPMailer(true);

                try {
                    // Configuración del servidor SMTP (puedes cambiar esto según tus necesidades)
                    $mail->isSMTP();
                    $mail->Host = 'smtp-mail.outlook.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'hec_thor2162@hotmail.com';
                    $mail->Password = '020616Prah#';
                    $mail->SMTPSecure = 'tls';
                    $mail->Port = 587;

                    // Configuración del remitente y destinatario
                    $mail->setFrom('hec_thor2162@hotmail.com', 'Soporte Tecnico Dept.Psicologia');
                    $mail->addAddress($correo);

                    // Contenido del correo
                    $mail->isHTML(true);
                    $mail->Subject = 'Recuperación de Contraseña';
                    $mail->Body    = 'Hola ' . $nombre . ',<br> Aquí está tu codigo de seguridad. Ingresa lo antes posible este codigo:' . $codigo;

                    // Enviar correo
                    $mail->send();

                    // Mensaje de éxito
                    echo "<div class='success-message'>Correo encontrado. Se ha enviado un mensaje de recuperación a tu dirección de correo.</div>";
                } catch (Exception $e) {
                    // Mensaje en caso de error
                    echo "Error al enviar el correo: {$mail->ErrorInfo}";
                }

                include("codigo5digitos.php");
                echo "Correo encontrado";
            } else {
                include("recuperacionLogin.html");
                echo "<h1>Correo no encontrado. Intenta de nuevo</h1>";
            }
        
            $stmt->close();
        } else {
            echo "Error en la preparación de la consulta: " . $conexion->error;
        }

    }


}if($TIPO_USUARIO=='tutor'){

    if(isset($_POST['enviarCodigo'])){
        $consulta="SELECT NOMBRE, A_PATERNO FROM TUTOR WHERE CORREOE=?";
        $stmt=$conexion->prepare($consulta);

        if ($stmt) {
            $stmt->bind_param("s",$correo);
            $stmt->execute();
            $resultado = $stmt->get_result();
            $filas = $resultado->fetch_assoc();
        
            if ($filas) {
                $nombre = $filas['NOMBRE'];
                $apellidoPaterno = $filas['A_PATERNO'];

                $query="UPDATE TUTOR SET TOKEN=? WHERE CORREOE=?";
                $stdi=$conexion->prepare($query);
                $stdi->bind_param("is",$codigo,$correo);
                $stdi->execute();
                $result=$stdi->get_result();

                $mail = new PHPMailer(true);

                try {
                    // Configuración del servidor SMTP (puedes cambiar esto según tus necesidades)
                    $mail->isSMTP();
                    $mail->Host = 'smtp-mail.outlook.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'hec_thor2162@hotmail.com';
                    $mail->Password = '020616Prah#';
                    $mail->SMTPSecure = 'tls';
                    $mail->Port = 587;

                    // Configuración del remitente y destinatario
                    $mail->setFrom('hec_thor2162@hotmail.com', 'Soporte Tecnico Dept.Psicologia');
                    $mail->addAddress($correo);

                    // Contenido del correo
                    $mail->isHTML(true);
                    $mail->Subject = 'Recuperación de Contraseña';
                    $mail->Body    = 'Hola ' . $nombre . ',<br> Aquí está tu codigo de seguridad. Ingresa lo antes posible este codigo:' . $codigo;

                    // Enviar correo
                    $mail->send();

                    // Mensaje de éxito
                    echo "<div class='success-message'>Correo encontrado. Se ha enviado un mensaje de recuperación a tu dirección de correo.</div>";
                } catch (Exception $e) {
                    // Mensaje en caso de error
                    echo "Error al enviar el correo: {$mail->ErrorInfo}";
                }

                include("codigo5digitos.php");
                echo "Correo encontrado";
            } else {
                include("recuperacionLogin.html");
                echo "<h1>Correo no encontrado. Intenta de nuevo</h1>";
            }
        
            $stmt->close();
        } else {
            echo "Error en la preparación de la consulta: " . $conexion->error;
        }

    }

}

?>


