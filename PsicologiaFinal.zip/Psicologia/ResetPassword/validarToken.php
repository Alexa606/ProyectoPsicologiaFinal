<?php

    session_start();

    $conexion = new mysqli("127.0.0.1", "root", "", "psicologa");
    $conexion->set_charset("utf8");

    $token=$_POST['recoverytoken'];    

    if(isset($_POST['intoCodigo'])){
        $consulta='SELECT *FROM SUPER_USUARIO WHERE TOKEN=?';
        $stmt=$conexion->prepare($consulta);
        $stmt->bind_param("i", $token);
        $stmt->execute();
        $resultado = $stmt->get_result();
        $filas = $resultado->num_rows;
        
        if ($filas) {
            $_SESSION['recoverytoken'] = $token;
            header("Location: cambioContraseña.html");
        } else {
            $query1="SELECT *FROM TUTOR WHERE TOKEN=?";
            $stdi1=$conexion->prepare($query1);
            $stdi1->bind_param("i",$token);
            $stdi1->execute();
            $resul=$stdi1->get_result();
            $files=$resul->num_rows;

            if($files){
                $_SESSION['recoverytoken'] = $token;
                header("Location: cambioContraseña.html");
            }else{
                include("codigo5digitos.php");
                echo 'Codigo de Seguridad Invalido';
            }

            $stdi1->close();

        }
        
        $stmt->close();
    }

?>