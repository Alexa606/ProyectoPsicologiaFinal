<?php

session_start();

$conexion = new mysqli("127.0.0.1", "root", "", "psicologa");
$conexion->set_charset("utf8");

$CONTRASENA=$_POST['nuevaContrasena'];
$NUEVACONTRASENA=$_POST['repiteContrasena'];
$token = $_SESSION['recoverytoken'];


if (isset($_POST['updateContra'])) {
    // Recupera el token de la sesión
    // Lógica de actualización de contraseña
    $querySuperUsuario = "SELECT * FROM SUPER_USUARIO WHERE TOKEN=?";
    $stmtSuperUsuario = $conexion->prepare($querySuperUsuario);
    $stmtSuperUsuario->bind_param("i", $token);
    $stmtSuperUsuario->execute();
    $resultSuperUsuario = $stmtSuperUsuario->get_result();
    $rowsSuperUsuario = $resultSuperUsuario->num_rows;

    if ($rowsSuperUsuario) {
        // Encontró el token en SUPER_USUARIO
        $queryUpdateSuperUsuario = "UPDATE SUPER_USUARIO SET CONTRASENA=? WHERE TOKEN=?";
        $stmtUpdateSuperUsuario = $conexion->prepare($queryUpdateSuperUsuario);
        $stmtUpdateSuperUsuario->bind_param("si", $CONTRASENA, $token);
        $stmtUpdateSuperUsuario->execute();
        

        if ($stmtUpdateSuperUsuario->affected_rows>0) {
            header("Location: cambioContraseña.html");
            echo "Contraseña actualizada.";
            
        } else {
            
            echo "Error al actualizar la contraseña en SUPER_USUARIO";
        }

        $stmtUpdateSuperUsuario->close();
    } else {
        // No encontró el token en SUPER_USUARIO, buscar en TUTOR
        $queryTutor = "SELECT * FROM TUTOR WHERE TOKEN=?";
        $stmtTutor = $conexion->prepare($queryTutor);
        $stmtTutor->bind_param("i", $token);
        $stmtTutor->execute();
        $resultTutor = $stmtTutor->get_result();
        $rowsTutor = $resultTutor->num_rows;

        if ($rowsTutor) {
            // Encontró el token en TUTOR
            $queryUpdateTutor = "UPDATE TUTOR SET CONTRASEÑA=? WHERE TOKEN=?";
            $stmtUpdateTutor = $conexion->prepare($queryUpdateTutor);
            $stmtUpdateTutor->bind_param("si", $CONTRASENA, $token);
            $stmtUpdateTutor->execute();
            

            if ($stmtUpdateTutor->affected_rows>0) {
                header("Location: cambioContraseña.html");
                echo "Contraseña Actualizada";
            } else {
                echo "Error al actualizar la contraseña vuelve a solicitar un codigo";
            }

            $stmtUpdateTutor->close();
        } else {
            // No encontró el token en TUTOR
            include("recuperacionLogin.html");
            echo 'Intente de nuevo';
        }

        $stmtTutor->close();
    }

    $stmtSuperUsuario->close();
    $conexion->close();
}

?>
