<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de sesión</title>
    <link rel="stylesheet" type="text/css" href="https:stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="estilosLogin.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
</head>

<header>
    <div class="logo">
        <img class="logo-img" src="images/LogoTec.jpg" alt="tesJO">
        <h2 class="title">Departamento de Psicología</h2>
        <img src="images/logo-psicologia.png" alt="psi">
    </div>
</header>
<body>
    <!--<h2 class="subtitulo">¡Bienvenido! Inicie Sesión</h2>-->
    <div class="container">
        <div class="esiloform">
            <form action="Inicio.php" method="POST">
                <h2 class="titulo-login" justify-content="center">Inicio de Sesión</h2>
                <div class="form-group">
                    <input type="text" class="form-control" name="CLAVE" placeholder="Clave de Usuario" required>
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" name="CONTRASEÑA"  placeholder="Contraseña" required>
                </div>
                <div class="form-group">
                    <select class="form-control" name="TIPO_USUARIO" required>
                        <option value="" disabled selected>Seleccione rol de usuario</option>
                        <option value="psicologo">Psicólogo</option>
                        <option value="tutor">Tutor</option>
                    </select>
                </div>
                <button type="submit" class="btn btn-primary" name="login">Iniciar Sesión</button> 
            </form>
        </div>
        <p class="mt-3">¿Olvidaste tu contraseña? <a href="ResetPassword/recuperacionLogin.html">Da clic aquí!</a></p>
    </div>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>    
</body>
</html>

