<?php
header('Content-Type: text/html; charset=UTF-8');
    $CLAVECARRERA = $_POST['CLAVECARRERA'];
    $CARRERA = $_POST['CARRERA'];
    $PLANESTUDIO = $_POST['PLANESTUDIO'];
    $CLAVEJD = $_POST['CLAVEJD'];
    
    $conexion = new mysqli("127.0.0.1", "root", "", "psicologa");
    $conexion->set_charset("utf8");

    if ($conexion->connect_error) {
        die("Error de conexión a la base de datos: " . $conexion->connect_error);
        }
    
if (isset($_POST['RegistrarCARRERA'])) {

        $consulta = "INSERT INTO CARRERA (CLAVECARRERA, CARRERA, PLANESTUDIO, CLAVEJD)
                    VALUES (?, ?, ?, ?)";
        $stmt = $conexion->prepare($consulta);

        if ($stmt) {
         $stmt->bind_param("issi", $CLAVECARRERA, $CARRERA, $PLANESTUDIO, $CLAVEJD);
 
         if ($stmt->execute()) {
             echo "La carrera registró con éxito.";
         } else {
             echo "Error al dar alta de carrera: " . $stmt->error;
         }
 
         $stmt->close();
     } else {
         echo "Error en la preparación de la consulta: " . $conexion->error;
     }
     
 
 }

if (isset($_POST['ActualizarCARRERA'])) {
   if ($conexion) {
       $consulta = "UPDATE CARRERA  
           SET CARRERA = :CARRERA, PLANESTUDIO = :PLANESTUDIO, CLAVEJD = :CLAVEJD
           WHERE CLAVECARRERA = :CLAVECARRERA";
       $stid = oci_parse($conexion, $consulta);

        oci_bind_by_name($stid, ':CLAVECARRERA', $CLAVECARRERA);
        oci_bind_by_name($stid, ':CARRERA', $CARRERA);
        oci_bind_by_name($stid, ':PLANESTUDIO', $PLANESTUDIO);
        oci_bind_by_name($stid, ':CLAVEJD', $CLAVEJD);

       if (oci_execute($stid)) {
           echo "La actualización se realizó con éxito.";
       } else {
           echo "Error al actualizar carrera.";
       }

       oci_close($conexion);
   } else {
       echo "Error de conexión a la base de datos.";
   }
}

if (isset($_POST['EliminarCARRERA'])) {
    $consulta = "DELETE FROM CARRERA
        WHERE CLAVECARRERA = ?";
    $stmt=$conexion->prepare($consulta);

    if($stmt){
        $stmt->bind_param("i",$CLAVECARRERA);
        if ($stmt->execute()) {
           echo "La carrera se elimino con exito.";
        } else {
           echo "Error al eliminar carrera.".$stmt->error;
        }

        $stmt->close();
    } else {
       echo "Error de conexión a la base de datos: ". $conexion->error;
    }
}



?>
